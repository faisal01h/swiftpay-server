export default function ApplicationLogo(props) {
    return (
        <img src="/assets/SWIFT.png" width={64} />
    );
}
