export default function Forbidden() {
    return (
        <div>
            403 Forbidden
        </div>
    )
}
