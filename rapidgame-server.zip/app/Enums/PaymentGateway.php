<?php

namespace App\Enums;

enum PaymentGateway: string
{
    case XENDIT = 'xendit';
}
